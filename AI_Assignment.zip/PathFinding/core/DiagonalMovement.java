package core;

public class DiagonalMovement {

	// ==== Constants ====
	
	public static final int ALWAYS = 0;
	public static final int NEVER = 1;
	public static final int IF_AT_MOST_ONE_OBSTACLE = 2;
	public static final int ONLY_WHEN_NO_OBSTACLES = 3;
}
